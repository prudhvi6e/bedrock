// Import necessary modules
import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";
import { fileURLToPath } from "url";

// Function to invoke the Bedrock model
export const invokeModel = async (prompt, modelId = "amazon.titan-text-express-v1") => {
  // Create a new Bedrock client instance
  const client = new BedrockRuntimeClient({ region: "ap-south-1" });

  // Prepare the payload for the model
  const payload = {
    inputText: prompt,
    textGenerationConfig: {
      maxTokenCount: 2000, // Limit to the token size you want
      stopSequences: [],   // Optional stop sequences (can leave empty)
      temperature: 0.7,    // Temperature for randomness control
      topP: 1,             // Controls diversity (1 = more diverse)
    },
  };

  // Create the command for invoking the model
  const command = new InvokeModelCommand({
    contentType: "application/json",
    body: JSON.stringify(payload),
    modelId,  // The model ID for the Bedrock Titan model
  });

  // Send the command to the Bedrock client and receive a response
  const apiResponse = await client.send(command);

  // Decode the response body
  const decodedResponseBody = new TextDecoder().decode(apiResponse.body);
  const responseBody = JSON.parse(decodedResponseBody);
  
  // Return the generated text from the model
  return responseBody.results[0].outputText;
};

// Main logic to run the function directly
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const prompt = 'Human: what is CMMI level certification?';  const modelId = "amazon.titan-text-express-v1";

  console.log(`Prompt: ${prompt}`);
  console.log(`Model ID: ${modelId}`);

  try {
    // Invoke the model with the prompt and model ID
    const response = await invokeModel(prompt, modelId);
    console.log("Generated Text:", response);
  } catch (err) {
    console.error("Error invoking the model:", err);
  }
}
