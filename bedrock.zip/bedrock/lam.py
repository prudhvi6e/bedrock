import boto3
import json

# Initialize the boto3 client for Bedrock
client = boto3.client(
    service_name='bedrock-runtime', 
    region_name='ap-south-1'  # Change to your AWS region
)

# Define the input prompt
prompt = {
    "inputText": "What are the benefits of using AI in business?"
}

# Call the amazon.titan-text-express-v1 model
response = client.invoke_model(
    modelId='amazon.titan-text-express-v1',  # The model ID
    contentType='application/json',
    accept='application/json',
    body=json.dumps(prompt)
)

# Read the StreamingBody object into a string
response_body = response['body'].read().decode('utf-8')

# Parse the JSON response
output = json.loads(response_body)

# Print the result
print(output['results'][0]['outputText'])